#!/usr/bin/env python3
"""
Manual Bot Starter Script
Run this file to start the Discord bot manually
"""

import subprocess
import sys
import os

def start_bot():
    """Start the Discord bot"""
    print("🤖 Starting WaxYyy Database Bot...")
    print("💡 Press Ctrl+C to stop the bot")
    print("=" * 50)
    
    try:
        # Run the main bot file
        subprocess.run([sys.executable, "main.py"], check=True)
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    except subprocess.CalledProcessError as e:
        print(f"❌ Bot crashed with exit code: {e.returncode}")
    except Exception as e:
        print(f"❌ Error starting bot: {e}")

if __name__ == "__main__":
    start_bot()