# Animated Avatar & Banner Examples for Discord Bot

Here are some high-quality animated GIF URLs you can use with the `!update_avatar` and `!update_banner` commands:

## Cyberpunk/Futuristic Themes
- https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif (Matrix-style digital rain)
- https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif (Holographic interface)
- https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif (Neon circuit patterns)

## Quantum/Energy Effects
- https://media.giphy.com/media/xT9IgEYXACITBhMLas/giphy.gif (Energy sphere)
- https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif (Particle effects)
- https://media.giphy.com/media/xT9IgG50Fb7Mi0prBC/giphy.gif (Plasma effects)

## Gaming/Tech Aesthetic
- https://media.giphy.com/media/26tn33aiTi1jkl6H6/giphy.gif (Retro computer)
- https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif (Digital effects)

## Banner-Specific Examples (16:9 Aspect Ratio)
- https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif (Wide holographic interface)
- https://media.giphy.com/media/26tn33aiTi1jkl6H6/giphy.gif (Cyberpunk cityscape)
- https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif (Neon circuit banner)

## Usage Instructions
### Avatar Commands
1. Use: `!update_avatar <URL>`
2. Example: `!update_avatar https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif`

### Banner Commands
1. Use: `!update_banner <URL>`
2. Example: `!update_banner https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif`

## Requirements
### General
- Administrator permissions required
- Supported formats: GIF, PNG, JPG, WEBP
- Discord API rate limits apply

### Avatar Specific
- Recommended size: 512x512 pixels (square)
- Maximum file size: 10MB (Discord API limit)
- Rate limit: 2 changes per hour

### Banner Specific  
- Recommended size: 960x540 pixels (16:9 ratio)
- Maximum file size: 10MB
- **Important: Bot needs Discord Nitro for banner support**
- Rate limit: 2 changes per 10 minutes

## Custom Tips
### Avatar Tips
- Use high-resolution images (512x512 recommended)
- Square aspect ratio looks best
- Animated GIFs work best at 30fps or lower
- Keep file size under 10MB (Discord's maximum limit)

### Banner Tips
- Use 960x540 resolution for optimal display
- 16:9 aspect ratio is required
- Banners display prominently on profile
- Consider horizontal composition for best impact
- Keep important elements away from edges
- Test visibility with different Discord themes