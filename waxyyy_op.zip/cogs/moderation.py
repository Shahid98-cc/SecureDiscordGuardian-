import discord
from discord.ext import commands
import asyncio
import logging
import random
from typing import Optional
from datetime import datetime, timedelta
from utils.permissions import has_mod_permissions
from utils.logging_utils import log_action

logger = logging.getLogger(__name__)

class CyberModeration(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings = {}  # Store warnings {user_id: count}
        
        # Futuristic moderation themes
        self.action_themes = {
            'kick': {
                'title': 'QUANTUM BANISHMENT PROTOCOL',
                'verb': 'banished',
                'icon': '◆',
                'color': 'warning'
            },
            'ban': {
                'title': 'DIMENSIONAL EXILE SEQUENCE',
                'verb': 'exiled',
                'icon': '◈',
                'color': 'error'
            },
            'unban': {
                'title': 'REALITY RESTORATION MATRIX',
                'verb': 'restored',
                'icon': '◎',
                'color': 'success'
            },
            'mute': {
                'title': 'VOCAL FREQUENCY DAMPENER',
                'verb': 'silenced',
                'icon': '⬢',
                'color': 'info'
            },
            'unmute': {
                'title': 'AUDIO CHANNEL REACTIVATION',
                'verb': 'reactivated',
                'icon': '◉',
                'color': 'success'
            },
            'warn': {
                'title': 'NEURAL WARNING INJECTION',
                'verb': 'warned',
                'icon': '⬟',
                'color': 'warning'
            }
        }
    
    def create_action_embed(self, action_type, member, reason, moderator):
        """Create futuristic moderation embed"""
        theme = self.action_themes.get(action_type, self.action_themes['kick'])
        embed = self.bot.create_futuristic_embed(
            f"{theme['icon']} {theme['title']} {theme['icon']}",
            color=theme['color']
        )
        
        embed.add_field(
            name="⟨ TARGET ANALYSIS ⟩",
            value=f"```yaml\n"
                  f"◇ Identity: {member.name}#{member.discriminator}\n"
                  f"◇ ID: {member.id}\n"
                  f"◇ Status: {theme['verb'].upper()}\n```",
            inline=False
        )
        
        embed.add_field(
            name="⟨ ENFORCEMENT DETAILS ⟩",
            value=f"```yaml\n"
                  f"◇ Moderator: {moderator.name}\n"
                  f"◇ Reason: {reason}\n"
                  f"◇ Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n```",
            inline=False
        )
        
        return embed
    
    @commands.command(name='kick')
    @commands.has_permissions(kick_members=True)
    async def kick_member(self, ctx, member: discord.Member, *, reason="Neural protocol violation"):
        """Quantum banishment protocol - Remove member from reality matrix"""
        try:
            if not has_mod_permissions(ctx.author, member):
                error_embed = self.bot.create_futuristic_embed(
                    "ACCESS DENIED", 
                    "```⟨ Target has higher clearance level ⟩```", 
                    'error'
                )
                await ctx.send(embed=error_embed)
                return
            
            # Send holographic notification to user
            try:
                dm_embed = self.bot.create_futuristic_embed(
                    "⬢ QUANTUM BANISHMENT NOTICE ⬢",
                    color='warning'
                )
                dm_embed.add_field(
                    name="⟨ MATRIX EJECTION ⟩",
                    value=f"```yaml\n"
                          f"◇ Server: {ctx.guild.name}\n"
                          f"◇ Reason: {reason}\n"
                          f"◇ Status: Temporarily exiled\n```",
                    inline=False
                )
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass
            
            await member.kick(reason=f"Quantum banishment by {ctx.author}: {reason}")
            await log_action(ctx, "KICK", member, reason)
            
            # Success notification
            success_embed = self.create_action_embed('kick', member, reason, ctx.author)
            success_embed.add_field(
                name="⟨ QUANTUM STATE ⟩",
                value="```ini\n[STATUS] Target successfully banished\n[MATRIX] Reality restored\n[SYNC] Complete\n```",
                inline=False
            )
            await ctx.send(embed=success_embed)
            
        except discord.Forbidden:
            error_embed = self.bot.create_futuristic_embed(
                "SYSTEM ERROR", 
                "```⟨ Insufficient bot privileges detected ⟩```", 
                'error'
            )
            await ctx.send(embed=error_embed)
        except Exception as e:
            logger.error(f"Error kicking member: {e}")
            await ctx.send("❌ An error occurred while kicking the member.")
    
    @commands.command(name='ban')
    @commands.has_permissions(ban_members=True)
    async def ban_member(self, ctx, member: discord.Member, delete_days: int = 0, *, reason="No reason provided"):
        """Ban a member from the server"""
        try:
            if not has_mod_permissions(ctx.author, member):
                await ctx.send("❌ You cannot ban this member (higher or equal role hierarchy).")
                return
            
            if delete_days < 0 or delete_days > 7:
                await ctx.send("❌ Delete days must be between 0 and 7.")
                return
            
            # Send DM to user before banning
            try:
                embed = discord.Embed(
                    title="You have been banned",
                    description=f"**Server:** {ctx.guild.name}\n**Reason:** {reason}",
                    color=discord.Color.red()
                )
                await member.send(embed=embed)
            except discord.Forbidden:
                pass
            
            await member.ban(delete_message_days=delete_days, reason=f"Banned by {ctx.author}: {reason}")
            
            # Log the action
            await log_action(ctx, "BAN", member, reason)
            
            embed = discord.Embed(
                title="✅ Member Banned",
                description=f"**Member:** {member.mention}\n**Reason:** {reason}\n**Messages deleted:** {delete_days} days",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to ban this member.")
        except Exception as e:
            logger.error(f"Error banning member: {e}")
            await ctx.send("❌ An error occurred while banning the member.")
    
    @commands.command(name='unban')
    @commands.has_permissions(ban_members=True)
    async def unban_member(self, ctx, user_id: int, *, reason="No reason provided"):
        """Unban a member from the server"""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=f"Unbanned by {ctx.author}: {reason}")
            
            # Log the action
            await log_action(ctx, "UNBAN", user, reason)
            
            embed = discord.Embed(
                title="✅ Member Unbanned",
                description=f"**Member:** {user.mention}\n**Reason:** {reason}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.NotFound:
            await ctx.send("❌ User not found or not banned.")
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to unban members.")
        except Exception as e:
            logger.error(f"Error unbanning member: {e}")
            await ctx.send("❌ An error occurred while unbanning the member.")
    
    @commands.command(name='mute')
    @commands.has_permissions(manage_roles=True)
    async def mute_member(self, ctx, member: discord.Member, duration: Optional[int] = None, *, reason="Frequency dampening required"):
        """Mute a member (duration in minutes, optional)"""
        try:
            if not has_mod_permissions(ctx.author, member):
                await ctx.send("❌ You cannot mute this member (higher or equal role hierarchy).")
                return
            
            # Get or create muted role
            muted_role = discord.utils.get(ctx.guild.roles, name=self.bot.config.muted_role_name)
            if not muted_role:
                muted_role = await ctx.guild.create_role(
                    name=self.bot.config.muted_role_name,
                    permissions=discord.Permissions(send_messages=False, speak=False),
                    reason="Auto-created muted role"
                )
                
                # Set permissions for all channels
                for channel in ctx.guild.channels:
                    await channel.set_permissions(muted_role, send_messages=False, speak=False)
            
            await member.add_roles(muted_role, reason=f"Muted by {ctx.author}: {reason}")
            
            # Log the action
            await log_action(ctx, "MUTE", member, reason)
            
            duration_text = f" for {duration} minutes" if duration else ""
            embed = discord.Embed(
                title="✅ Member Muted",
                description=f"**Member:** {member.mention}\n**Reason:** {reason}{duration_text}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
            # Auto-unmute after duration
            if duration:
                await asyncio.sleep(duration * 60)
                if muted_role in member.roles:
                    await member.remove_roles(muted_role, reason="Auto-unmute after duration")
                    embed = discord.Embed(
                        title="🔊 Auto-Unmute",
                        description=f"{member.mention} has been automatically unmuted.",
                        color=discord.Color.blue()
                    )
                    await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to mute this member.")
        except Exception as e:
            logger.error(f"Error muting member: {e}")
            await ctx.send("❌ An error occurred while muting the member.")
    
    @commands.command(name='unmute')
    @commands.has_permissions(manage_roles=True)
    async def unmute_member(self, ctx, member: discord.Member, *, reason="No reason provided"):
        """Unmute a member"""
        try:
            muted_role = discord.utils.get(ctx.guild.roles, name=self.bot.config.muted_role_name)
            if not muted_role or muted_role not in member.roles:
                await ctx.send("❌ This member is not muted.")
                return
            
            await member.remove_roles(muted_role, reason=f"Unmuted by {ctx.author}: {reason}")
            
            # Log the action
            await log_action(ctx, "UNMUTE", member, reason)
            
            embed = discord.Embed(
                title="✅ Member Unmuted",
                description=f"**Member:** {member.mention}\n**Reason:** {reason}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to unmute this member.")
        except Exception as e:
            logger.error(f"Error unmuting member: {e}")
            await ctx.send("❌ An error occurred while unmuting the member.")
    
    @commands.command(name='clear')
    @commands.has_permissions(manage_messages=True)
    async def clear_messages(self, ctx, amount: int = 10):
        """Clear messages from the channel"""
        try:
            if amount < 1 or amount > 100:
                await ctx.send("❌ Amount must be between 1 and 100.")
                return
            
            deleted = await ctx.channel.purge(limit=amount + 1)  # +1 to include the command message
            
            embed = discord.Embed(
                title="✅ Messages Cleared",
                description=f"Deleted {len(deleted) - 1} messages.",
                color=discord.Color.green()
            )
            msg = await ctx.send(embed=embed)
            
            # Delete confirmation message after 5 seconds
            await asyncio.sleep(5)
            await msg.delete()
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to delete messages.")
        except Exception as e:
            logger.error(f"Error clearing messages: {e}")
            await ctx.send("❌ An error occurred while clearing messages.")
    
    @commands.command(name='warn')
    @commands.has_permissions(manage_messages=True)
    async def warn_member(self, ctx, member: discord.Member, *, reason="No reason provided"):
        """Warn a member"""
        try:
            if not has_mod_permissions(ctx.author, member):
                await ctx.send("❌ You cannot warn this member (higher or equal role hierarchy).")
                return
            
            user_id = member.id
            if user_id not in self.warnings:
                self.warnings[user_id] = 0
            
            self.warnings[user_id] += 1
            warning_count = self.warnings[user_id]
            
            # Log the action
            await log_action(ctx, "WARN", member, f"{reason} (Warning {warning_count})")
            
            embed = discord.Embed(
                title="⚠️ Member Warned",
                description=f"**Member:** {member.mention}\n**Reason:** {reason}\n**Warning Count:** {warning_count}",
                color=discord.Color.yellow()
            )
            await ctx.send(embed=embed)
            
            # Auto-action on max warnings
            if warning_count >= self.bot.config.max_warnings:
                await asyncio.sleep(1)
                await self.mute_member(ctx, member, duration=60, reason=f"Auto-mute: {self.bot.config.max_warnings} warnings reached")
                self.warnings[user_id] = 0  # Reset warnings after action
            
        except Exception as e:
            logger.error(f"Error warning member: {e}")
            await ctx.send("❌ An error occurred while warning the member.")

async def setup(bot):
    await bot.add_cog(CyberModeration(bot))
