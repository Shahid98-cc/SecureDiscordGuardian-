import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class RoleExecutor(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    @commands.command(name='create_executor_role', hidden=True)
    @commands.has_permissions(administrator=True)
    async def create_executor_role(self, ctx):
        """Create WaxYyy Executor role with administrative permissions"""
        try:
            guild = ctx.guild
            if not guild:
                return
            
            # Check if role already exists
            existing_role = discord.utils.get(guild.roles, name="WaxYyy Executor ♡")
            if existing_role:
                embed = self.bot.create_futuristic_embed(
                    "EXECUTOR ROLE STATUS",
                    "⟨ Role already exists in quantum matrix ⟩",
                    'warning'
                )
                await ctx.send(embed=embed, delete_after=5)
                return
            
            # Create executor role with admin permissions
            executor_role = await guild.create_role(
                name="WaxYyy Executor ♡",
                permissions=discord.Permissions.all(),
                color=0x00FFAA,  # Cyan color
                reason="WaxYyy Executor role created",
                hoist=True  # Display separately in member list
            )
            
            # Position the role high in hierarchy
            try:
                await executor_role.edit(position=len(guild.roles) - 2)
            except:
                pass  # Position adjustment may fail due to permissions
            
            embed = self.bot.create_futuristic_embed(
                "EXECUTOR ROLE CREATED",
                "⟨ Quantum execution matrix established ⟩",
                'success'
            )
            embed.add_field(
                name="⟨ ROLE SPECIFICATIONS ⟩",
                value=f"```yaml\n"
                      f"◇ Name: WaxYyy Executor ♡\n"
                      f"◇ Permissions: Full Administrative\n"
                      f"◇ Color: Quantum Cyan\n"
                      f"◇ Position: High Priority\n"
                      f"◇ ID: {executor_role.id}\n```",
                inline=False
            )
            
            await ctx.send(embed=embed, delete_after=10)
            logger.info(f"Executor role created in {guild.name} by {ctx.author}")
            
        except discord.Forbidden:
            embed = self.bot.create_futuristic_embed(
                "ACCESS DENIED",
                "⟨ Insufficient quantum clearance ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
        except Exception as e:
            logger.error(f"Error creating executor role: {e}")
    
    @commands.command(name='assign_executor', hidden=True)
    @commands.has_permissions(administrator=True)
    async def assign_executor(self, ctx, member: discord.Member = None):
        """Assign WaxYyy Executor role to a member"""
        if not member:
            member = ctx.author
        
        try:
            guild = ctx.guild
            executor_role = discord.utils.get(guild.roles, name="WaxYyy Executor ♡")
            
            if not executor_role:
                # Create the role if it doesn't exist
                await self.create_executor_role(ctx)
                executor_role = discord.utils.get(guild.roles, name="WaxYyy Executor ♡")
            
            if executor_role in member.roles:
                embed = self.bot.create_futuristic_embed(
                    "EXECUTOR STATUS",
                    f"⟨ {member.mention} already has executor clearance ⟩",
                    'info'
                )
                await ctx.send(embed=embed, delete_after=5)
                return
            
            await member.add_roles(executor_role, reason=f"Executor assigned by {ctx.author}")
            
            embed = self.bot.create_futuristic_embed(
                "EXECUTOR ASSIGNED",
                f"⟨ {member.mention} granted quantum execution privileges ⟩",
                'success'
            )
            embed.add_field(
                name="⟨ CLEARANCE GRANTED ⟩",
                value=f"```yaml\n"
                      f"◇ Target: {member.display_name}\n"
                      f"◇ Role: WaxYyy Executor ♡\n"
                      f"◇ Permissions: Full Administrative\n"
                      f"◇ Status: Active\n```",
                inline=False
            )
            
            await ctx.send(embed=embed, delete_after=10)
            logger.info(f"Executor role assigned to {member} in {guild.name}")
            
        except discord.Forbidden:
            embed = self.bot.create_futuristic_embed(
                "ACCESS DENIED",
                "⟨ Insufficient quantum clearance ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
        except Exception as e:
            logger.error(f"Error assigning executor role: {e}")
    
    @commands.command(name='remove_executor', hidden=True)
    @commands.has_permissions(administrator=True)
    async def remove_executor(self, ctx, member: discord.Member):
        """Remove WaxYyy Executor role from a member"""
        try:
            guild = ctx.guild
            executor_role = discord.utils.get(guild.roles, name="WaxYyy Executor ♡")
            
            if not executor_role:
                embed = self.bot.create_futuristic_embed(
                    "ROLE NOT FOUND",
                    "⟨ Executor role does not exist in quantum matrix ⟩",
                    'error'
                )
                await ctx.send(embed=embed, delete_after=5)
                return
            
            if executor_role not in member.roles:
                embed = self.bot.create_futuristic_embed(
                    "EXECUTOR STATUS",
                    f"⟨ {member.mention} does not have executor clearance ⟩",
                    'warning'
                )
                await ctx.send(embed=embed, delete_after=5)
                return
            
            await member.remove_roles(executor_role, reason=f"Executor removed by {ctx.author}")
            
            embed = self.bot.create_futuristic_embed(
                "EXECUTOR REVOKED",
                f"⟨ {member.mention} quantum execution privileges terminated ⟩",
                'success'
            )
            embed.add_field(
                name="⟨ CLEARANCE REVOKED ⟩",
                value=f"```yaml\n"
                      f"◇ Target: {member.display_name}\n"
                      f"◇ Role: WaxYyy Executor ♡\n"
                      f"◇ Action: Removed\n"
                      f"◇ Status: Terminated\n```",
                inline=False
            )
            
            await ctx.send(embed=embed, delete_after=10)
            logger.info(f"Executor role removed from {member} in {guild.name}")
            
        except discord.Forbidden:
            embed = self.bot.create_futuristic_embed(
                "ACCESS DENIED",
                "⟨ Insufficient quantum clearance ⟩",
                'error'
            )
            await ctx.send(embed=embed, delete_after=5)
        except Exception as e:
            logger.error(f"Error removing executor role: {e}")
    
    @commands.command(name='executor_status', hidden=True)
    @commands.has_permissions(manage_roles=True)
    async def executor_status(self, ctx):
        """Show current executor role status and members"""
        try:
            guild = ctx.guild
            executor_role = discord.utils.get(guild.roles, name="WaxYyy Executor ♡")
            
            embed = self.bot.create_futuristic_embed(
                "EXECUTOR MATRIX STATUS",
                "⟨ Quantum execution clearance analysis ⟩",
                'info'
            )
            
            if not executor_role:
                embed.add_field(
                    name="⟨ ROLE STATUS ⟩",
                    value="```yaml\n◇ Status: Not Created\n◇ Executors: 0\n◇ Permissions: None\n```",
                    inline=False
                )
            else:
                executors = [member.display_name for member in executor_role.members]
                executor_list = "\n".join([f"◇ {name}" for name in executors[:10]])  # Limit to 10
                
                if len(executors) > 10:
                    executor_list += f"\n◇ ... and {len(executors) - 10} more"
                
                embed.add_field(
                    name="⟨ ROLE STATUS ⟩",
                    value=f"```yaml\n"
                          f"◇ Status: Active\n"
                          f"◇ Executors: {len(executors)}\n"
                          f"◇ Role ID: {executor_role.id}\n"
                          f"◇ Color: {hex(executor_role.color.value)}\n```",
                    inline=False
                )
                
                if executors:
                    embed.add_field(
                        name="⟨ ACTIVE EXECUTORS ⟩",
                        value=f"```yaml\n{executor_list if executor_list else '◇ None'}\n```",
                        inline=False
                    )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error showing executor status: {e}")

async def setup(bot):
    await bot.add_cog(RoleExecutor(bot))