import discord
from discord.ext import commands
import asyncio
import yt_dlp
import json
import os
from collections import deque
import random
import time

class MusicPlayer:
    def __init__(self, bot):
        self.bot = bot
        self.queue = deque()
        self.current = None
        self.voice_client = None
        self.is_playing = False
        self.is_paused = False
        self.loop_mode = "off"  # off, track, queue
        self.volume = 0.5
        self.shuffle_mode = False
        self.auto_disconnect_task = None
        
    def add_to_queue(self, track):
        if self.shuffle_mode and len(self.queue) > 0:
            # Insert at random position when shuffle is on
            pos = random.randint(0, len(self.queue))
            self.queue.insert(pos, track)
        else:
            self.queue.append(track)
    
    def get_next_track(self):
        if self.loop_mode == "track" and self.current:
            return self.current
        elif len(self.queue) > 0:
            if self.loop_mode == "queue" and self.current:
                self.queue.append(self.current)
            return self.queue.popleft()
        return None

class QuantumMusic(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.players = {}  # Guild ID -> MusicPlayer
        self.load_music_config()
        
        # Enhanced YT-DLP options for better quality and reliability
        self.ytdl_format_options = {
            'format': 'bestaudio/best',
            'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
            'restrictfilenames': True,
            'noplaylist': True,
            'nocheckcertificate': True,
            'ignoreerrors': False,
            'logtostderr': False,
            'quiet': True,
            'no_warnings': True,
            'default_search': 'auto',
            'source_address': '0.0.0.0',
            'extract_flat': False,
            'cachedir': False
        }
        
        self.ffmpeg_options = {
            'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
            'options': '-vn -filter:a "volume=0.5"'
        }
        
        self.ytdl = yt_dlp.YoutubeDL(self.ytdl_format_options)

    def load_music_config(self):
        """Load music configuration"""
        try:
            with open('music_config.json', 'r') as f:
                self.config = json.load(f)
        except FileNotFoundError:
            self.config = {
                "enabled": True,
                "max_queue_size": 100,
                "auto_disconnect_timeout": 300,  # 5 minutes
                "default_volume": 0.5,
                "allow_playlists": True,
                "max_track_duration": 3600  # 1 hour
            }
            self.save_music_config()

    def save_music_config(self):
        """Save music configuration"""
        with open('music_config.json', 'w') as f:
            json.dump(self.config, f, indent=2)

    def get_player(self, guild_id):
        """Get or create music player for guild"""
        if guild_id not in self.players:
            self.players[guild_id] = MusicPlayer(self.bot)
        return self.players[guild_id]

    async def extract_info(self, url_or_search):
        """Extract track information using yt-dlp"""
        try:
            loop = asyncio.get_event_loop()
            data = await loop.run_in_executor(None, lambda: self.ytdl.extract_info(url_or_search, download=False))
            
            if 'entries' in data:
                # Handle playlist
                if self.config["allow_playlists"]:
                    return data['entries']
                else:
                    return [data['entries'][0]] if data['entries'] else []
            else:
                return [data]
        except Exception as e:
            print(f"Error extracting info: {e}")
            return []

    def create_music_embed(self, title, description=None, color='quantum'):
        """Create quantum-themed music embed"""
        colors = {
            'quantum': 0x00FFFF,
            'playing': 0x00FF00,
            'paused': 0xFFFF00,
            'stopped': 0xFF0000,
            'queue': 0xFF00FF
        }
        
        embed = discord.Embed(
            title=f"🎵 {title}",
            description=description,
            color=colors.get(color, 0x00FFFF)
        )
        embed.set_footer(text="Quantum Music System • Advanced Audio Matrix")
        return embed

    def format_duration(self, seconds):
        """Format duration in seconds to readable format"""
        if not seconds:
            return "Unknown"
        
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    async def auto_disconnect(self, guild_id):
        """Auto disconnect after timeout"""
        await asyncio.sleep(self.config["auto_disconnect_timeout"])
        player = self.get_player(guild_id)
        if player.voice_client and not player.is_playing:
            await player.voice_client.disconnect()
            player.voice_client = None

    async def play_next(self, guild_id):
        """Play next track in queue"""
        player = self.get_player(guild_id)
        
        if not player.voice_client:
            return
            
        next_track = player.get_next_track()
        if not next_track:
            player.is_playing = False
            player.current = None
            # Start auto disconnect timer
            if player.auto_disconnect_task:
                player.auto_disconnect_task.cancel()
            player.auto_disconnect_task = asyncio.create_task(self.auto_disconnect(guild_id))
            return
        
        try:
            # Get fresh URL for streaming
            info = await self.extract_info(next_track['webpage_url'])
            if not info:
                await self.play_next(guild_id)
                return
            
            track_info = info[0]
            player.current = track_info
            
            # Create audio source
            source = discord.FFmpegPCMAudio(track_info['url'], **self.ffmpeg_options)
            source = discord.PCMVolumeTransformer(source, volume=player.volume)
            
            # Play audio
            player.voice_client.play(source, after=lambda e: asyncio.run_coroutine_threadsafe(self.play_next(guild_id), self.bot.loop))
            player.is_playing = True
            player.is_paused = False
            
        except Exception as e:
            print(f"Error playing track: {e}")
            await self.play_next(guild_id)

    @commands.command(name='join', aliases=['connect'])
    async def join_voice(self, ctx):
        """Connect to user's voice channel"""
        if not ctx.author.voice:
            embed = self.create_music_embed("❌ Neural Connection Error", "You must be in a voice channel to use quantum audio systems", "stopped")
            await ctx.send(embed=embed)
            return
        
        channel = ctx.author.voice.channel
        player = self.get_player(ctx.guild.id)
        
        if player.voice_client:
            await player.voice_client.move_to(channel)
        else:
            player.voice_client = await channel.connect()
        
        embed = self.create_music_embed("🔗 Quantum Link Established", f"Connected to **{channel.name}**\nAudio matrix synchronized", "quantum")
        await ctx.send(embed=embed)

    @commands.command(name='play', aliases=['p'])
    async def play_music(self, ctx, *, query: str):
        """Play music from YouTube or search query"""
        if not self.config["enabled"]:
            await ctx.send("🚫 Music system is currently disabled")
            return
        
        # Auto-join if not connected
        if not ctx.author.voice:
            embed = self.create_music_embed("❌ Neural Connection Error", "You must be in a voice channel", "stopped")
            await ctx.send(embed=embed)
            return
        
        player = self.get_player(ctx.guild.id)
        if not player.voice_client:
            await self.join_voice(ctx)
        
        # Show loading message
        loading_embed = self.create_music_embed("🔍 Quantum Search Active", f"Scanning audio matrix for: **{query}**", "quantum")
        loading_msg = await ctx.send(embed=loading_embed)
        
        # Extract track info
        tracks = await self.extract_info(query)
        if not tracks:
            embed = self.create_music_embed("❌ Search Failed", "No audio data found in quantum matrix", "stopped")
            await loading_msg.edit(embed=embed)
            return
        
        # Add tracks to queue
        added_count = 0
        for track in tracks[:self.config["max_queue_size"]]:
            if track.get('duration', 0) <= self.config["max_track_duration"]:
                player.add_to_queue(track)
                added_count += 1
        
        if added_count == 0:
            embed = self.create_music_embed("❌ No Valid Tracks", "All tracks exceed maximum duration limit", "stopped")
            await loading_msg.edit(embed=embed)
            return
        
        # Create response embed
        if added_count == 1:
            track = tracks[0]
            embed = self.create_music_embed(
                "✅ Track Added to Queue",
                f"**{track.get('title', 'Unknown')}**\n"
                f"Duration: {self.format_duration(track.get('duration'))}\n"
                f"Position in queue: {len(player.queue)}",
                "queue"
            )
            if track.get('thumbnail'):
                embed.set_thumbnail(url=track['thumbnail'])
        else:
            embed = self.create_music_embed(
                f"✅ Added {added_count} Tracks",
                f"Quantum playlist integrated into audio matrix\nTotal queue size: {len(player.queue)}",
                "queue"
            )
        
        await loading_msg.edit(embed=embed)
        
        # Start playing if not already playing
        if not player.is_playing and not player.voice_client.is_playing():
            await self.play_next(ctx.guild.id)

    @commands.command(name='pause')
    async def pause_music(self, ctx):
        """Pause current track"""
        player = self.get_player(ctx.guild.id)
        if player.voice_client and player.voice_client.is_playing():
            player.voice_client.pause()
            player.is_paused = True
            embed = self.create_music_embed("⏸️ Audio Matrix Paused", "Quantum stream temporarily suspended", "paused")
            await ctx.send(embed=embed)
        else:
            embed = self.create_music_embed("❌ No Active Stream", "No audio currently playing in quantum matrix", "stopped")
            await ctx.send(embed=embed)

    @commands.command(name='resume')
    async def resume_music(self, ctx):
        """Resume paused track"""
        player = self.get_player(ctx.guild.id)
        if player.voice_client and player.voice_client.is_paused():
            player.voice_client.resume()
            player.is_paused = False
            embed = self.create_music_embed("▶️ Audio Matrix Resumed", "Quantum stream restored", "playing")
            await ctx.send(embed=embed)
        else:
            embed = self.create_music_embed("❌ No Paused Stream", "No paused audio in quantum matrix", "stopped")
            await ctx.send(embed=embed)

    @commands.command(name='skip', aliases=['next'])
    async def skip_track(self, ctx):
        """Skip current track"""
        player = self.get_player(ctx.guild.id)
        if player.voice_client and (player.voice_client.is_playing() or player.voice_client.is_paused()):
            player.voice_client.stop()
            embed = self.create_music_embed("⏭️ Track Skipped", "Advancing to next quantum frequency", "quantum")
            await ctx.send(embed=embed)
        else:
            embed = self.create_music_embed("❌ No Active Stream", "No audio to skip in quantum matrix", "stopped")
            await ctx.send(embed=embed)

    @commands.command(name='stop')
    async def stop_music(self, ctx):
        """Stop music and clear queue"""
        player = self.get_player(ctx.guild.id)
        if player.voice_client:
            player.voice_client.stop()
            player.queue.clear()
            player.current = None
            player.is_playing = False
            embed = self.create_music_embed("⏹️ Audio Matrix Terminated", "All quantum streams stopped and queue cleared", "stopped")
            await ctx.send(embed=embed)
        else:
            embed = self.create_music_embed("❌ No Active Connection", "No audio matrix to terminate", "stopped")
            await ctx.send(embed=embed)

    @commands.command(name='queue', aliases=['q'])
    async def show_queue(self, ctx, page: int = 1):
        """Show current music queue"""
        player = self.get_player(ctx.guild.id)
        
        if not player.current and len(player.queue) == 0:
            embed = self.create_music_embed("📭 Empty Queue", "No tracks in quantum audio matrix", "queue")
            await ctx.send(embed=embed)
            return
        
        embed = self.create_music_embed("🎵 Quantum Audio Matrix", color="queue")
        
        # Current track
        if player.current:
            status = "▶️ Playing" if player.is_playing and not player.is_paused else "⏸️ Paused"
            embed.add_field(
                name="🎵 Current Track",
                value=f"{status}\n**{player.current.get('title', 'Unknown')}**\nDuration: {self.format_duration(player.current.get('duration'))}",
                inline=False
            )
        
        # Queue
        if len(player.queue) > 0:
            items_per_page = 10
            start_idx = (page - 1) * items_per_page
            end_idx = start_idx + items_per_page
            
            queue_text = ""
            for i, track in enumerate(list(player.queue)[start_idx:end_idx], start_idx + 1):
                queue_text += f"`{i}.` **{track.get('title', 'Unknown')[:50]}**\n"
            
            if queue_text:
                embed.add_field(
                    name=f"📋 Queue ({len(player.queue)} tracks)",
                    value=queue_text,
                    inline=False
                )
            
            # Pagination info
            total_pages = (len(player.queue) + items_per_page - 1) // items_per_page
            if total_pages > 1:
                embed.set_footer(text=f"Page {page}/{total_pages} • Quantum Music System")
        
        # Player settings
        settings = []
        if player.loop_mode != "off":
            settings.append(f"🔁 Loop: {player.loop_mode}")
        if player.shuffle_mode:
            settings.append("🔀 Shuffle: ON")
        settings.append(f"🔊 Volume: {int(player.volume * 100)}%")
        
        if settings:
            embed.add_field(name="⚙️ Settings", value=" | ".join(settings), inline=False)
        
        await ctx.send(embed=embed)

    @commands.command(name='volume', aliases=['vol'])
    async def set_volume(self, ctx, volume: int):
        """Set music volume (0-100)"""
        if not 0 <= volume <= 100:
            embed = self.create_music_embed("❌ Invalid Volume", "Volume must be between 0 and 100", "stopped")
            await ctx.send(embed=embed)
            return
        
        player = self.get_player(ctx.guild.id)
        player.volume = volume / 100
        
        if player.voice_client and hasattr(player.voice_client.source, 'volume'):
            player.voice_client.source.volume = player.volume
        
        embed = self.create_music_embed("🔊 Volume Adjusted", f"Quantum audio level set to {volume}%", "quantum")
        await ctx.send(embed=embed)

    @commands.command(name='loop')
    async def toggle_loop(self, ctx, mode: str = None):
        """Toggle loop mode (off/track/queue)"""
        player = self.get_player(ctx.guild.id)
        
        if mode and mode.lower() in ['off', 'track', 'queue']:
            player.loop_mode = mode.lower()
        else:
            # Cycle through modes
            modes = ['off', 'track', 'queue']
            current_idx = modes.index(player.loop_mode)
            player.loop_mode = modes[(current_idx + 1) % len(modes)]
        
        mode_names = {'off': 'Disabled', 'track': 'Current Track', 'queue': 'Entire Queue'}
        embed = self.create_music_embed("🔁 Loop Mode", f"Quantum loop set to: **{mode_names[player.loop_mode]}**", "quantum")
        await ctx.send(embed=embed)

    @commands.command(name='shuffle')
    async def toggle_shuffle(self, ctx):
        """Toggle shuffle mode"""
        player = self.get_player(ctx.guild.id)
        player.shuffle_mode = not player.shuffle_mode
        
        status = "Enabled" if player.shuffle_mode else "Disabled"
        embed = self.create_music_embed("🔀 Shuffle Mode", f"Quantum randomization {status.lower()}", "quantum")
        await ctx.send(embed=embed)

    @commands.command(name='disconnect', aliases=['leave'])
    async def disconnect_voice(self, ctx):
        """Disconnect from voice channel"""
        player = self.get_player(ctx.guild.id)
        if player.voice_client:
            await player.voice_client.disconnect()
            player.voice_client = None
            player.queue.clear()
            player.current = None
            player.is_playing = False
            
            embed = self.create_music_embed("🔌 Quantum Link Severed", "Disconnected from audio matrix", "stopped")
            await ctx.send(embed=embed)
        else:
            embed = self.create_music_embed("❌ No Active Connection", "Not connected to any audio matrix", "stopped")
            await ctx.send(embed=embed)

    @commands.command(name='nowplaying', aliases=['np'])
    async def now_playing(self, ctx):
        """Show currently playing track"""
        player = self.get_player(ctx.guild.id)
        
        if not player.current:
            embed = self.create_music_embed("❌ No Active Stream", "No track currently in quantum matrix", "stopped")
            await ctx.send(embed=embed)
            return
        
        track = player.current
        status = "▶️ Playing" if player.is_playing and not player.is_paused else "⏸️ Paused"
        
        embed = self.create_music_embed("🎵 Now Playing", color="playing")
        embed.add_field(
            name="Current Track",
            value=f"{status}\n**{track.get('title', 'Unknown')}**\n"
                  f"Duration: {self.format_duration(track.get('duration'))}\n"
                  f"Uploader: {track.get('uploader', 'Unknown')}",
            inline=False
        )
        
        if track.get('thumbnail'):
            embed.set_thumbnail(url=track['thumbnail'])
        
        # Add queue info
        queue_size = len(player.queue)
        if queue_size > 0:
            embed.add_field(name="Queue", value=f"{queue_size} tracks remaining", inline=True)
        
        # Add settings
        settings = []
        if player.loop_mode != "off":
            settings.append(f"🔁 {player.loop_mode}")
        if player.shuffle_mode:
            settings.append("🔀 Shuffle")
        settings.append(f"🔊 {int(player.volume * 100)}%")
        
        embed.add_field(name="Settings", value=" | ".join(settings), inline=True)
        
        await ctx.send(embed=embed)

    @commands.group(name='music')
    @commands.has_permissions(administrator=True)
    async def music_settings(self, ctx):
        """Music system configuration"""
        if ctx.invoked_subcommand is None:
            embed = self.create_music_embed("⚙️ Music System Configuration", color="quantum")
            embed.add_field(name="Enabled", value="✅ Yes" if self.config["enabled"] else "❌ No", inline=True)
            embed.add_field(name="Max Queue Size", value=str(self.config["max_queue_size"]), inline=True)
            embed.add_field(name="Auto Disconnect", value=f"{self.config['auto_disconnect_timeout']}s", inline=True)
            embed.add_field(name="Allow Playlists", value="✅ Yes" if self.config["allow_playlists"] else "❌ No", inline=True)
            embed.add_field(name="Max Track Duration", value=f"{self.config['max_track_duration']}s", inline=True)
            embed.add_field(name="Default Volume", value=f"{int(self.config['default_volume'] * 100)}%", inline=True)
            await ctx.send(embed=embed)

    @music_settings.command(name='toggle')
    @commands.has_permissions(administrator=True)
    async def toggle_music_system(self, ctx):
        """Toggle music system on/off"""
        self.config["enabled"] = not self.config["enabled"]
        self.save_music_config()
        
        status = "Enabled" if self.config["enabled"] else "Disabled"
        embed = self.create_music_embed(f"🎵 Music System {status}", f"Quantum audio matrix {status.lower()}", "quantum")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(QuantumMusic(bot))