import discord
from discord.ext import commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class DMBlocker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.dm_config = self.load_dm_config()
    
    def load_dm_config(self):
        """Load DM blocking configuration"""
        default_config = {
            "block_dms": True,
            "send_warning": True,
            "allowed_users": [],  # User IDs that can DM the bot
            "warning_message": "DM communications are disabled. Please use server channels."
        }
        
        try:
            if os.path.exists('dm_config.json'):
                with open('dm_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading DM config: {e}")
        
        return default_config
    
    def save_dm_config(self):
        """Save DM configuration"""
        try:
            with open('dm_config.json', 'w') as f:
                json.dump(self.dm_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving DM config: {e}")
    
    @commands.Cog.listener()
    async def on_message(self, message):
        """Block DMs to the bot"""
        if message.author.bot:
            return
        
        # Only process DMs
        if message.guild:
            return
        
        # Check if DM blocking is enabled
        if not self.dm_config.get("block_dms", True):
            return
        
        # Check if user is in allowed list
        if message.author.id in self.dm_config.get("allowed_users", []):
            return
        
        # Send warning if enabled
        if self.dm_config.get("send_warning", True):
            try:
                embed = self.bot.create_futuristic_embed(
                    "⟨ ⚠️ QUANTUM ACCESS DENIED ⚠️ ⟩",
                    "```yaml\n"
                    f"◇ {self.dm_config.get('warning_message', 'DM communications disabled')}\n"
                    "◇ Neural network protocols require server-based communication\n"
                    "◇ Please use authorized channels in your server\n"
                    "◇ Contact server administrators for assistance\n```",
                    'warning'
                )
                embed.add_field(
                    name="⟨ ◈ SECURITY PROTOCOL ◈ ⟩",
                    value="```ini\n"
                          "[BLOCKED] Direct message transmission\n"
                          "[REASON] Unauthorized communication channel\n"
                          "[ACTION] Use server channels only\n```",
                    inline=False
                )
                await message.channel.send(embed=embed)
                logger.info(f"Blocked DM from {message.author} ({message.author.id})")
            except Exception as e:
                logger.error(f"Error sending DM warning: {e}")
    
    @commands.command(name='dm_toggle')
    @commands.has_permissions(administrator=True)
    async def toggle_dm_blocking(self, ctx):
        """Toggle DM blocking on/off"""
        self.dm_config["block_dms"] = not self.dm_config["block_dms"]
        self.save_dm_config()
        
        status = "ENABLED" if self.dm_config["block_dms"] else "DISABLED"
        embed = self.bot.create_futuristic_embed(
            "⟨ ◈ DM SECURITY MATRIX ◈ ⟩",
            f"```yaml\n"
            f"◇ DM Blocking Status: {status}\n"
            f"◇ Warning Messages: {'ON' if self.dm_config['send_warning'] else 'OFF'}\n"
            f"◇ Allowed Users: {len(self.dm_config['allowed_users'])}\n```",
            'neural'
        )
        await ctx.send(embed=embed)
    
    @commands.command(name='dm_allow')
    @commands.has_permissions(administrator=True)
    async def allow_dm_user(self, ctx, user: discord.User):
        """Allow a specific user to DM the bot"""
        if user.id not in self.dm_config["allowed_users"]:
            self.dm_config["allowed_users"].append(user.id)
            self.save_dm_config()
            
            embed = self.bot.create_futuristic_embed(
                "⟨ ✅ ACCESS GRANTED ⟩",
                f"```yaml\n"
                f"◇ User: {user.display_name}\n"
                f"◇ ID: {user.id}\n"
                f"◇ Status: DM access authorized\n```",
                'success'
            )
        else:
            embed = self.bot.create_futuristic_embed(
                "⟨ ⚠️ ALREADY AUTHORIZED ⟩",
                f"```yaml\n"
                f"◇ User: {user.display_name}\n"
                f"◇ Status: Already has DM access\n```",
                'warning'
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='dm_deny')
    @commands.has_permissions(administrator=True)
    async def deny_dm_user(self, ctx, user: discord.User):
        """Remove DM access for a specific user"""
        if user.id in self.dm_config["allowed_users"]:
            self.dm_config["allowed_users"].remove(user.id)
            self.save_dm_config()
            
            embed = self.bot.create_futuristic_embed(
                "⟨ ❌ ACCESS REVOKED ⟩",
                f"```yaml\n"
                f"◇ User: {user.display_name}\n"
                f"◇ ID: {user.id}\n"
                f"◇ Status: DM access removed\n```",
                'error'
            )
        else:
            embed = self.bot.create_futuristic_embed(
                "⟨ ⚠️ NOT AUTHORIZED ⟩",
                f"```yaml\n"
                f"◇ User: {user.display_name}\n"
                f"◇ Status: No DM access to remove\n```",
                'warning'
            )
        
        await ctx.send(embed=embed)
    
    @commands.command(name='dm_status')
    @commands.has_permissions(manage_guild=True)
    async def show_dm_status(self, ctx):
        """Show current DM blocking status"""
        embed = self.bot.create_futuristic_embed(
            "⟨ ◈ DM SECURITY STATUS ◈ ⟩",
            "⟨ Current quantum communication protocols ⟩",
            'neural'
        )
        
        embed.add_field(
            name="⟨ 🛡️ BLOCKING STATUS ⟩",
            value=f"```yaml\n"
                  f"◇ DM Blocking: {'ACTIVE' if self.dm_config['block_dms'] else 'INACTIVE'}\n"
                  f"◇ Warning Messages: {'ENABLED' if self.dm_config['send_warning'] else 'DISABLED'}\n```",
            inline=False
        )
        
        if self.dm_config["allowed_users"]:
            allowed_users = []
            for user_id in self.dm_config["allowed_users"]:
                try:
                    user = self.bot.get_user(user_id)
                    if user:
                        allowed_users.append(f"◇ {user.display_name} ({user_id})")
                    else:
                        allowed_users.append(f"◇ Unknown User ({user_id})")
                except:
                    allowed_users.append(f"◇ User ID: {user_id}")
            
            embed.add_field(
                name="⟨ ✅ AUTHORIZED USERS ⟩",
                value=f"```yaml\n" + "\n".join(allowed_users[:10]) + "\n```",
                inline=False
            )
        else:
            embed.add_field(
                name="⟨ ✅ AUTHORIZED USERS ⟩",
                value="```yaml\n◇ No users have DM access\n```",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(DMBlocker(bot))