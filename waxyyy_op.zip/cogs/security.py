import discord
from discord.ext import commands
import logging
from datetime import datetime
from utils.logging_utils import log_action

logger = logging.getLogger(__name__)

class Security(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='lockdown')
    @commands.has_permissions(manage_channels=True)
    async def lockdown_server(self, ctx, *, reason="Emergency lockdown"):
        """Lock down all text channels"""
        try:
            locked_channels = []
            failed_channels = []
            
            for channel in ctx.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(ctx.guild.default_role)
                    overwrites.send_messages = False
                    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrites, reason=f"Lockdown by {ctx.author}: {reason}")
                    locked_channels.append(channel.name)
                except discord.Forbidden:
                    failed_channels.append(channel.name)
            
            # Log the action
            await log_action(ctx, "LOCKDOWN", None, f"Server lockdown: {reason}")
            
            embed = discord.Embed(
                title="🔒 Server Lockdown Initiated",
                description=f"**Reason:** {reason}\n**Locked channels:** {len(locked_channels)}",
                color=discord.Color.red()
            )
            
            if failed_channels:
                embed.add_field(name="Failed to lock", value=", ".join(failed_channels), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error during lockdown: {e}")
            await ctx.send("❌ An error occurred during lockdown.")
    
    @commands.command(name='unlock')
    @commands.has_permissions(manage_channels=True)
    async def unlock_server(self, ctx, *, reason="Lockdown lifted"):
        """Unlock all text channels"""
        try:
            unlocked_channels = []
            failed_channels = []
            
            for channel in ctx.guild.text_channels:
                try:
                    overwrites = channel.overwrites_for(ctx.guild.default_role)
                    overwrites.send_messages = None  # Reset to default
                    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrites, reason=f"Unlock by {ctx.author}: {reason}")
                    unlocked_channels.append(channel.name)
                except discord.Forbidden:
                    failed_channels.append(channel.name)
            
            # Log the action
            await log_action(ctx, "UNLOCK", None, f"Server unlocked: {reason}")
            
            embed = discord.Embed(
                title="🔓 Server Unlocked",
                description=f"**Reason:** {reason}\n**Unlocked channels:** {len(unlocked_channels)}",
                color=discord.Color.green()
            )
            
            if failed_channels:
                embed.add_field(name="Failed to unlock", value=", ".join(failed_channels), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error during unlock: {e}")
            await ctx.send("❌ An error occurred during unlock.")
    
    @commands.command(name='slowmode')
    @commands.has_permissions(manage_channels=True)
    async def set_slowmode(self, ctx, seconds: int = 0):
        """Set slowmode for the current channel"""
        try:
            if seconds < 0 or seconds > 21600:  # Discord limit is 6 hours
                await ctx.send("❌ Slowmode must be between 0 and 21600 seconds (6 hours).")
                return
            
            await ctx.channel.edit(slowmode_delay=seconds, reason=f"Slowmode set by {ctx.author}")
            
            # Log the action
            await log_action(ctx, "SLOWMODE", ctx.channel, f"Set slowmode to {seconds} seconds")
            
            if seconds == 0:
                embed = discord.Embed(
                    title="✅ Slowmode Disabled",
                    description=f"Slowmode has been disabled in {ctx.channel.mention}",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="✅ Slowmode Enabled",
                    description=f"Slowmode set to {seconds} seconds in {ctx.channel.mention}",
                    color=discord.Color.blue()
                )
            
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            await ctx.send("❌ I don't have permission to manage this channel.")
        except Exception as e:
            logger.error(f"Error setting slowmode: {e}")
            await ctx.send("❌ An error occurred while setting slowmode.")
    
    @commands.command(name='userinfo')
    async def user_info(self, ctx, member: discord.Member = None):
        """Get detailed information about a user"""
        try:
            if member is None:
                member = ctx.author
            
            embed = discord.Embed(
                title=f"👤 User Information: {member.display_name}",
                color=member.color
            )
            
            embed.set_thumbnail(url=member.display_avatar.url)
            embed.add_field(name="Username", value=f"{member.name}#{member.discriminator}", inline=True)
            embed.add_field(name="User ID", value=member.id, inline=True)
            embed.add_field(name="Display Name", value=member.display_name, inline=True)
            embed.add_field(name="Account Created", value=member.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
            embed.add_field(name="Joined Server", value=member.joined_at.strftime("%Y-%m-%d %H:%M:%S") if member.joined_at else "Unknown", inline=True)
            embed.add_field(name="Status", value=str(member.status).title(), inline=True)
            
            # Roles
            roles = [role.mention for role in member.roles if role.name != "@everyone"]
            if roles:
                embed.add_field(name=f"Roles ({len(roles)})", value=", ".join(roles), inline=False)
            
            # Permissions
            perms = []
            if member.guild_permissions.administrator:
                perms.append("Administrator")
            if member.guild_permissions.manage_guild:
                perms.append("Manage Server")
            if member.guild_permissions.manage_roles:
                perms.append("Manage Roles")
            if member.guild_permissions.kick_members:
                perms.append("Kick Members")
            if member.guild_permissions.ban_members:
                perms.append("Ban Members")
            
            if perms:
                embed.add_field(name="Key Permissions", value=", ".join(perms), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error getting user info: {e}")
            await ctx.send("❌ An error occurred while getting user information.")
    
    @commands.command(name='serverinfo')
    async def server_info(self, ctx):
        """Get detailed information about the server"""
        try:
            guild = ctx.guild
            
            embed = discord.Embed(
                title=f"🏠 Server Information: {guild.name}",
                color=discord.Color.blue()
            )
            
            if guild.icon:
                embed.set_thumbnail(url=guild.icon.url)
            
            embed.add_field(name="Server ID", value=guild.id, inline=True)
            embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)
            embed.add_field(name="Created", value=guild.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
            embed.add_field(name="Members", value=guild.member_count, inline=True)
            embed.add_field(name="Roles", value=len(guild.roles), inline=True)
            embed.add_field(name="Channels", value=len(guild.channels), inline=True)
            embed.add_field(name="Text Channels", value=len(guild.text_channels), inline=True)
            embed.add_field(name="Voice Channels", value=len(guild.voice_channels), inline=True)
            embed.add_field(name="Verification Level", value=str(guild.verification_level).title(), inline=True)
            
            # Server features
            if guild.features:
                features = [feature.replace('_', ' ').title() for feature in guild.features]
                embed.add_field(name="Features", value=", ".join(features), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error getting server info: {e}")
            await ctx.send("❌ An error occurred while getting server information.")
    
    @commands.command(name='channelinfo')
    async def channel_info(self, ctx, channel: discord.TextChannel = None):
        """Get information about a channel"""
        try:
            if channel is None:
                channel = ctx.channel
            
            embed = discord.Embed(
                title=f"📺 Channel Information: {channel.name}",
                color=discord.Color.blue()
            )
            
            embed.add_field(name="Name", value=channel.name, inline=True)
            embed.add_field(name="ID", value=channel.id, inline=True)
            embed.add_field(name="Type", value=str(channel.type).title(), inline=True)
            embed.add_field(name="Category", value=channel.category.name if channel.category else "None", inline=True)
            embed.add_field(name="Position", value=channel.position, inline=True)
            embed.add_field(name="NSFW", value="Yes" if channel.nsfw else "No", inline=True)
            embed.add_field(name="Slowmode", value=f"{channel.slowmode_delay} seconds" if channel.slowmode_delay else "Disabled", inline=True)
            embed.add_field(name="Created", value=channel.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
            
            if channel.topic:
                embed.add_field(name="Topic", value=channel.topic, inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            logger.error(f"Error getting channel info: {e}")
            await ctx.send("❌ An error occurred while getting channel information.")

async def setup(bot):
    await bot.add_cog(Security(bot))
