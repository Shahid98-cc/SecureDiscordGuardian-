import discord
from discord.ext import commands
import asyncio
import logging
from datetime import datetime
import json
import os

logger = logging.getLogger(__name__)

class Broadcast(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.broadcast_config = self.load_broadcast_config()
        self.active_broadcasts = {}  # Track ongoing broadcasts
    
    def load_broadcast_config(self):
        """Load broadcast configuration"""
        default_config = {
            "enabled": True,
            "delay_between_messages": 1.0,  # seconds
            "max_batch_size": 50,  # messages per batch
            "retry_failed": True,
            "log_results": True,
            "allow_roles": ["Administrator", "STAFF TEAM", "Moderator"]
        }
        
        try:
            if os.path.exists('broadcast_config.json'):
                with open('broadcast_config.json', 'r') as f:
                    config = json.load(f)
                    return {**default_config, **config}
        except Exception as e:
            logger.error(f"Error loading broadcast config: {e}")
        
        return default_config
    
    def save_broadcast_config(self):
        """Save broadcast configuration"""
        try:
            with open('broadcast_config.json', 'w') as f:
                json.dump(self.broadcast_config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving broadcast config: {e}")
    
    def can_broadcast(self, member: discord.Member) -> bool:
        """Check if member can send broadcasts"""
        if member.guild_permissions.administrator:
            return True
        
        allowed_roles = self.broadcast_config.get("allow_roles", [])
        return any(role.name in allowed_roles for role in member.roles)
    
    async def send_dm_with_retry(self, member: discord.Member, embed: discord.Embed, retries: int = 2):
        """Send DM with retry logic"""
        for attempt in range(retries + 1):
            try:
                await member.send(embed=embed)
                return {"status": "success", "member_id": member.id}
            except discord.Forbidden:
                return {"status": "forbidden", "member_id": member.id, "reason": "DMs disabled"}
            except discord.HTTPException as e:
                if attempt < retries:
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
                    continue
                return {"status": "failed", "member_id": member.id, "reason": str(e)}
            except Exception as e:
                return {"status": "error", "member_id": member.id, "reason": str(e)}
        
        return {"status": "failed", "member_id": member.id, "reason": "Max retries exceeded"}
    
    @commands.command(name='broadcast')
    @commands.has_permissions(administrator=True)
    async def broadcast_message(self, ctx, *, message: str):
        """Broadcast a message to all server members via DM
        
        Usage: !broadcast Your message here
        """
        if not self.broadcast_config.get("enabled", True):
            await ctx.send("❌ Broadcasting is currently disabled.")
            return
        
        if not self.can_broadcast(ctx.author):
            await ctx.send("❌ You don't have permission to send broadcasts.")
            return
        
        if ctx.guild.id in self.active_broadcasts:
            await ctx.send("❌ Another broadcast is already in progress for this server.")
            return
        
        # Confirmation
        confirm_embed = discord.Embed(
            title="📢 Broadcast Confirmation",
            description=f"Are you sure you want to send this message to **{ctx.guild.member_count}** members?",
            color=discord.Color.orange()
        )
        confirm_embed.add_field(name="Message Preview", value=message[:1024], inline=False)
        confirm_embed.add_field(name="⚠️ Warning", value="This action cannot be undone!", inline=False)
        confirm_embed.set_footer(text="React with ✅ to confirm or ❌ to cancel (30 seconds)")
        
        confirm_msg = await ctx.send(embed=confirm_embed)
        await confirm_msg.add_reaction("✅")
        await confirm_msg.add_reaction("❌")
        
        def check(reaction, user):
            return (user == ctx.author and 
                   str(reaction.emoji) in ["✅", "❌"] and 
                   reaction.message.id == confirm_msg.id)
        
        try:
            reaction, user = await self.bot.wait_for('reaction_add', check=check, timeout=30.0)
            
            if str(reaction.emoji) == "❌":
                await ctx.send("❌ Broadcast cancelled.")
                return
            
        except asyncio.TimeoutError:
            await ctx.send("⏰ Broadcast confirmation timed out.")
            return
        
        # Start broadcast
        await self.execute_broadcast(ctx, message)
    
    async def execute_broadcast(self, ctx, message: str):
        """Execute the broadcast to all members"""
        guild = ctx.guild
        members = [member for member in guild.members if not member.bot]
        
        # Mark broadcast as active
        self.active_broadcasts[guild.id] = {
            "started_by": ctx.author.id,
            "started_at": datetime.utcnow(),
            "total_members": len(members),
            "sent": 0,
            "failed": 0
        }
        
        # Create broadcast embed
        broadcast_embed = discord.Embed(
            title=f"📢 Announcement from {guild.name}",
            description=message,
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        broadcast_embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
        broadcast_embed.set_footer(text=f"Sent by {ctx.author.display_name}")
        
        # Progress tracking
        progress_embed = discord.Embed(
            title="📤 Broadcasting in Progress",
            description=f"Sending to {len(members)} members...",
            color=discord.Color.yellow()
        )
        progress_msg = await ctx.send(embed=progress_embed)
        
        # Broadcast results
        results = {
            "success": 0,
            "forbidden": 0,
            "failed": 0,
            "errors": []
        }
        
        delay = self.broadcast_config.get("delay_between_messages", 1.0)
        batch_size = self.broadcast_config.get("max_batch_size", 50)
        
        # Send messages in batches
        for i in range(0, len(members), batch_size):
            batch = members[i:i + batch_size]
            tasks = []
            
            for member in batch:
                task = self.send_dm_with_retry(member, broadcast_embed)
                tasks.append(task)
            
            # Execute batch
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Process results
            for result in batch_results:
                if isinstance(result, dict):
                    status = result.get("status", "error")
                    if status == "success":
                        results["success"] += 1
                    elif status == "forbidden":
                        results["forbidden"] += 1
                    else:
                        results["failed"] += 1
                        if result.get("reason"):
                            results["errors"].append(result["reason"])
                else:
                    results["failed"] += 1
                    results["errors"].append(str(result))
            
            # Update progress
            progress = i + len(batch)
            self.active_broadcasts[guild.id]["sent"] = results["success"]
            self.active_broadcasts[guild.id]["failed"] = results["forbidden"] + results["failed"]
            
            if progress % 25 == 0 or progress == len(members):  # Update every 25 members or at end
                progress_embed.description = f"Progress: {progress}/{len(members)} members\nSent: {results['success']} | Failed: {results['forbidden'] + results['failed']}"
                await progress_msg.edit(embed=progress_embed)
            
            # Delay between batches
            if i + batch_size < len(members):
                await asyncio.sleep(delay)
        
        # Cleanup
        del self.active_broadcasts[guild.id]
        
        # Final results
        completion_embed = discord.Embed(
            title="✅ Broadcast Complete",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        completion_embed.add_field(name="📊 Results", value=f"**Successful:** {results['success']}\n**DMs Disabled:** {results['forbidden']}\n**Failed:** {results['failed']}", inline=True)
        completion_embed.add_field(name="📈 Success Rate", value=f"{(results['success'] / len(members) * 100):.1f}%", inline=True)
        completion_embed.add_field(name="👥 Total Members", value=len(members), inline=True)
        
        await progress_msg.edit(embed=completion_embed)
        
        # Log results if enabled
        if self.broadcast_config.get("log_results", True):
            logger.info(f"Broadcast completed by {ctx.author} in {guild.name}: {results['success']}/{len(members)} successful")
    
    @commands.command(name='broadcast_announcement')
    @commands.has_permissions(administrator=True)
    async def broadcast_announcement(self, ctx, title: str, *, message: str):
        """Broadcast a formatted announcement to all server members
        
        Usage: !broadcast_announcement "Title Here" Your announcement message here
        """
        if not self.broadcast_config.get("enabled", True):
            await ctx.send("❌ Broadcasting is currently disabled.")
            return
        
        if not self.can_broadcast(ctx.author):
            await ctx.send("❌ You don't have permission to send broadcasts.")
            return
        
        if ctx.guild.id in self.active_broadcasts:
            await ctx.send("❌ Another broadcast is already in progress for this server.")
            return
        
        # Create formatted message
        formatted_message = f"**{title}**\n\n{message}"
        
        # Confirmation with preview
        confirm_embed = discord.Embed(
            title="📢 Announcement Broadcast Confirmation",
            description=f"Sending to **{ctx.guild.member_count}** members:",
            color=discord.Color.orange()
        )
        confirm_embed.add_field(name=title, value=message[:1024], inline=False)
        confirm_embed.set_footer(text="React with ✅ to confirm or ❌ to cancel (30 seconds)")
        
        confirm_msg = await ctx.send(embed=confirm_embed)
        await confirm_msg.add_reaction("✅")
        await confirm_msg.add_reaction("❌")
        
        def check(reaction, user):
            return (user == ctx.author and 
                   str(reaction.emoji) in ["✅", "❌"] and 
                   reaction.message.id == confirm_msg.id)
        
        try:
            reaction, user = await self.bot.wait_for('reaction_add', check=check, timeout=30.0)
            
            if str(reaction.emoji) == "❌":
                await ctx.send("❌ Announcement cancelled.")
                return
            
        except asyncio.TimeoutError:
            await ctx.send("⏰ Announcement confirmation timed out.")
            return
        
        # Start announcement broadcast
        await self.execute_broadcast(ctx, formatted_message)
    
    @commands.command(name='broadcast_status')
    @commands.has_permissions(administrator=True)
    async def broadcast_status(self, ctx):
        """Check current broadcast status"""
        if ctx.guild.id not in self.active_broadcasts:
            await ctx.send("📭 No active broadcasts for this server.")
            return
        
        broadcast = self.active_broadcasts[ctx.guild.id]
        started_by = self.bot.get_user(broadcast["started_by"])
        
        embed = discord.Embed(
            title="📤 Active Broadcast Status",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="Started By", value=started_by.mention if started_by else "Unknown", inline=True)
        embed.add_field(name="Started At", value=broadcast["started_at"].strftime("%H:%M:%S"), inline=True)
        embed.add_field(name="Progress", value=f"{broadcast['sent']}/{broadcast['total_members']}", inline=True)
        embed.add_field(name="Failed", value=broadcast["failed"], inline=True)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='broadcast_config')
    @commands.has_permissions(administrator=True)
    async def show_broadcast_config(self, ctx):
        """Show broadcast configuration"""
        config = self.broadcast_config
        
        embed = discord.Embed(
            title="⚙️ Broadcast Configuration",
            color=discord.Color.blue()
        )
        
        embed.add_field(name="Enabled", value="✅" if config.get("enabled") else "❌", inline=True)
        embed.add_field(name="Message Delay", value=f"{config.get('delay_between_messages')}s", inline=True)
        embed.add_field(name="Batch Size", value=config.get("max_batch_size"), inline=True)
        embed.add_field(name="Retry Failed", value="✅" if config.get("retry_failed") else "❌", inline=True)
        embed.add_field(name="Log Results", value="✅" if config.get("log_results") else "❌", inline=True)
        embed.add_field(name="Allowed Roles", value=", ".join(config.get("allow_roles", [])), inline=False)
        
        await ctx.send(embed=embed)
    
    @commands.command(name='broadcast_toggle')
    @commands.has_permissions(administrator=True)
    async def toggle_broadcast(self, ctx):
        """Toggle broadcast system on/off"""
        self.broadcast_config["enabled"] = not self.broadcast_config.get("enabled", True)
        self.save_broadcast_config()
        
        status = "enabled" if self.broadcast_config["enabled"] else "disabled"
        embed = discord.Embed(
            title="✅ Broadcast System Updated",
            description=f"Broadcasting is now {status}.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Broadcast(bot))