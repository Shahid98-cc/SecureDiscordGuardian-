# WaxYyy Database Bot - Installation Guide

## Quick Setup

1. **Extract the ZIP file**
   ```bash
   unzip waxyy_database_bot.zip
   cd waxyy_database_bot/
   ```

2. **Install Python dependencies**
   ```bash
   pip install discord.py aiohttp pillow psutil pydub pynacl youtube-dl yt-dlp
   ```

3. **Set your Discord bot token**
   ```bash
   export DISCORD_BOT_TOKEN="your_bot_token_here"
   ```

4. **Run the bot**
   ```bash
   python main.py
   ```

## Features Included
- Complete moderation system with anti-nuke protection
- Music streaming with YouTube integration
- Staff management with daily reports and task assignment
- Leveling system with XP rewards and leaderboards
- Auto-moderation with AI behavior detection
- Welcome system with customizable messages
- Advanced role management and permissions
- Broadcast messaging to all members
- Truth or Dare entertainment system
- Holographic UI with quantum-themed interfaces
- Real-time analytics and server monitoring
- DM blocking and security features
- Profile theme customization for the bot

## System Requirements
- Python 3.8 or higher
- FFmpeg (for music playback)
- 100MB+ free disk space
- Stable internet connection

## Discord Bot Setup
1. Go to Discord Developer Portal
2. Create new application and bot
3. Copy the bot token
4. Invite bot with Administrator permissions
5. Set the token as environment variable

## Auto-Restart Feature
The bot automatically restarts every 1 minute to maintain optimal performance and apply any updates seamlessly.

## Default Configuration
- Prefix: `!`
- Status: DND (Do Not Disturb)
- Activity: Playing ♡ WaxYyy's Database ♡ --> !help
- Auto-restart: Every 60 seconds